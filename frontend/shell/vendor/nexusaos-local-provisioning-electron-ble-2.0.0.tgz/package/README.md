# @nexusaos/local-provisioning-electron-ble

Electron BLE GATT v2 framing and Web Bluetooth transport for the fixed `f6c7...` provisioning service. It transports complete logical JSON-Line frames and never decrypts or executes payloads.

The trusted Setup Renderer owns `BluetoothDevice` and exposes a narrow reverse-RPC target:

```ts
const selection = createElectronBluetoothSelectionEndpoint({ bluetooth: navigator.bluetooth, clock });
const factory = createElectronGattTransportFactory({ consumeSelectionLease: selection.consumeSelectionLease, clock });
const endpoint = createElectronGattTransportEndpoint({ factory });

// Directly inside the Scan button's user gesture:
const candidate = await selection.requestDeviceFromUserGesture();
// Send only `candidate` to Main. Main calls endpoint.connect/readDeviceInfo/request/
// subscribeStatus/close over authenticated, ordered IPC using opaque connection IDs.
```

Main installs its visible chooser policy for the trusted Setup `webContents` with `installElectronBluetoothPicker` from the `./main` export. The picker never receives a `BluetoothDevice`, certificate, Wi-Fi secret, or decrypted protocol payload.
