# @nexusaos/device-provisioning-uni

Transport-neutral provisioning orchestration for uni-app. The package owns
the typed provisioning state machine and command/status correlation, while the
embedding application supplies the Bluetooth or SoftAP transport adapter and
the platform-specific device-attestation implementation.

It deliberately contains no Vue pages, account storage, access tokens,
private keys, Android reflection, or cloud HTTP client. Pairing proof creation
and the Owner API are injected through `OwnerPairingProvider`, so an app can
keep its Android Keystore and authenticated request implementation in a
trusted host.

The current box protocol is selected explicitly with `protocolVersion: 1` or
`2`. Legacy schema 1 is retained only for development compatibility; production
devices must use the approved AEAD v2 protocol once the box/platform rollout is
complete.

```ts
import {
  createProvisioningSession,
  createProvisioningCommand,
} from "@nexusaos/device-provisioning-uni";

const session = createProvisioningSession(bluetoothAdapter, {
  protocolVersion: 2,
});
const devices = await session.scan();
const device = await session.connect(devices[0].transportId);
await session.provisionWifi({ ssid, password, security: "wpa-personal" });
```

Discovery candidates are not stable device identities. The adapter must read
and verify canonical `device_info` before returning a device that can be used
for pairing or Connectivity.
