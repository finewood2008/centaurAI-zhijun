# @nexusaos/local-provisioning-contracts

Exact public contracts for NexusAOS local provisioning protocol v2. This package contains no transport, account, persistence, or cryptographic implementation.
