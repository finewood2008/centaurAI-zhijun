# @nexusaos/consumer-contracts

Versioned Consumer v1 pairing DTOs and fail-closed runtime validators used by local provisioning v2.
