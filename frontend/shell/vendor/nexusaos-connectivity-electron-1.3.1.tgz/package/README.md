# `@nexusaos/connectivity-electron`

This package contains the Electron facade, a main-process sidecar host and a
private child-process exchange. It does not contain a WebRTC implementation;
the Go sidecar must be supplied as a separately signed, version-matched binary.

## Process boundary

The public `src/index.ts` facade is renderer-safe only when exposed through a
narrow Electron `contextBridge`. The files `src/native-host.ts` and
`src/sidecar-protocol.ts` are main-process-only. Do not bundle or import them in
preload, renderer, browser, Web or H5 code.

The session ticket is obtained by the injected `ElectronMainSessionTicketProvider`
and appears only in the main-to-sidecar `connect` request. It must remain in
main/sidecar memory, must not be stored, logged, returned by `exchange`, placed
in an exception, or sent through `ipcMain`/`ipcRenderer`.

`createElectronAdminTicketProvider` adapts the approved Admin Connectivity
session response and verifies the returned application, platform, scopes,
purpose, profile and transport before serializing the ticket for the sidecar.
`SOVEREIGN_DIRECT_ONLY`/`DIRECT_ONLY` is the unchanged first stage and accepts
STUN-only ICE configuration with no fallback fields. A separate, explicit
`REMOTEOPS_COMPATIBILITY`/`TURN_ONLY` request is accepted only with
`fallback_from_session_id` and a `DIRECT_TIMEOUT` or `ICE_FAILED` reason; its
Admin response must echo that provenance and contain TURN/TURNS-only servers
with short-lived `username`, `credential`, and `expiresAt` values. The injected Admin client remains responsible for login-token
refresh, secure client-key storage and `NEXUSAOS-CONSUMER-V1` request signing.

`createElectronSidecarNativeHost` rejects `electron-renderer`, `web` and `h5`
runtime labels. This is defense in depth; applications must also exclude the
main-only modules from their renderer/H5 build graph.

## JSON Lines IPC v1

Each IPC message is one UTF-8 JSON object followed by a single LF (`0x0a`). A
decoder accepts CRLF but an encoder always emits LF. Empty lines, unterminated
input, invalid UTF-8, invalid JSON, unsupported message shapes and a JSON line
larger than `ELECTRON_SIDECAR_MAX_JSON_LINE_BYTES` fail closed.

The host sends:

- `type=request, operation=connect`: binding plus the main-only ticket;
- `type=request, operation=request`: scoped relative HTTP request;
- `type=close, operation=close`: idempotent session close request.

The sidecar returns either a correlated `type=response` for the same
`request_id` and operation, or a correlated `type=error` with a stable code.
Connect success carries exact `selected_path` (`DIRECT` or `RELAY`) and `policy`
fields; the host rejects policy/path mismatches and exposes the final path as
`ElectronScopedSession.selectedPath`. For `connect` failures with
`code=SDK_DIRECT_UNAVAILABLE`, protocol v1 also accepts the optional bounded
`detail_code` values `ICE_FAILED` and `DIRECT_TIMEOUT`. A `failed_session_id`
is accepted only together with one of those safe details. No other operation,
primary code or detail value may carry those fields. The host exposes them as
`ElectronSidecarOperationError.detailCode` and `.failedSessionId`;
the error message remains the primary stable code and never contains native
cause text.
Response bodies use canonical base64 and are bounded by
`ELECTRON_SIDECAR_MAX_BODY_BYTES`. Tickets are separately bounded by
`ELECTRON_SIDECAR_MAX_TICKET_BYTES`.

This framing is intended for a private, authenticated child-process channel.
`src/process-exchange.ts` uses inherited stdin/stdout pipes and does not open a
TCP listener. The application must resolve the sidecar executable from its
signed installation, refuse a writable/untrusted path, pass a version-matched
binary, and close it on account logout, window teardown and application exit.
The exchange implements spawn, framing, correlation, timeout and crash cleanup;
signaling, ICE, WebRTC and DataChannel remain implemented by the Go sidecar.
`operationTimeoutMs` configures independent `connect`, `request` and `close`
watchdogs, with defaults of 20, 70 and 5 seconds. The 70-second request watchdog
allows the Core's bounded 60-second HTTP deadline to return its own stable
result. Deprecated `requestTimeoutMs` remains an all-operation fallback for
source and runtime compatibility, and an operation-specific value overrides
that fallback. An IPC watchdog expires the whole private exchange because
protocol v1 has no cancellation frame.

Process failures are sanitized as `IPC_SIDECAR_SPAWN_FAILED`,
`IPC_SIDECAR_EXITED` or `IPC_SIDECAR_TIMEOUT`. `IPC_SIDECAR_CLOSED` remains the
code for an explicitly closed exchange and for unrelated pending work when a
timed-out operation terminates the sidecar. Executable paths, exit status,
signals and stderr are never placed in these errors.

## Main-process integration

The main process injects these dependencies:

1. an authenticated Admin client owned by the application main process;
2. the signed, version-matched Go sidecar executable and trusted Gateway/ICE
   host arguments from signed installation configuration;
3. a collision-resistant request ID generator, supplied by the process host.

Tests may use an in-memory exchange. Production code must not treat an
in-memory fake, browser worker, fixed localhost TCP port or renderer bridge as a
sidecar transport.

Release `1.3.0` adds the explicit second-stage TURN contract and selected-path
evidence while retaining the Direct request behavior. `npm pack --dry-run`
verifies the consumer-visible files. A production application still requires a
same-version, signed sidecar and its target desktop OS support validation.
