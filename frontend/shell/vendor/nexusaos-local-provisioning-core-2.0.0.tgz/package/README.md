# @nexusaos/local-provisioning-core

Transport-neutral strict codec and cryptographic state for `NEXUSAOS_LOCAL_AEAD_V2`. Crypto and certificate operations are injected through `ProvisioningCryptoProvider`; no weak fallback exists.
