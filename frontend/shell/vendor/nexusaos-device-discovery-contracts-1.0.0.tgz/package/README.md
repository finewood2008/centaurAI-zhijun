# @nexusaos/device-discovery-contracts

Platform-neutral discovery v1 DTOs. Candidates and leases are ephemeral opaque handles and never contain a trusted device ID.
