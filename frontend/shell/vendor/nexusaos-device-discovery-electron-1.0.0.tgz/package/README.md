# @nexusaos/device-discovery-electron

Electron Main system-chooser discovery v1. It contains no provisioning commands, Wi-Fi payloads, GATT codec, or legacy plaintext implementation.

Install `installElectronBluetoothPicker` from `./main` before the trusted Setup
Renderer calls `navigator.bluetooth.requestDevice()` from a user gesture. Host
installation is passive: the resulting Chromium `select-bluetooth-device` event
starts one fresh eight-second session. Select, cancel, or timeout releases that
session while leaving the host ready for the next user click. The host publishes
only opaque candidates on `DISCOVERY_PICKER_CHANNELS.candidates`;
the preload forwards an explicit `select` or `cancel` IPC from the same
`webContents.mainFrame` and exact internal document URL. The returned synchronous,
idempotent cleanup function removes both IPC handlers, cancels the Chromium chooser,
and disposes the scan.

Selection of the Chromium chooser entry only resolves the Renderer Web Bluetooth
promise. The Renderer must then use
`createElectronBluetoothSelectionEndpoint()` from
`@nexusaos/local-provisioning-electron-ble` to issue the one-shot selection lease
that binds the in-memory `BluetoothDevice` to the GATT transport factory.
