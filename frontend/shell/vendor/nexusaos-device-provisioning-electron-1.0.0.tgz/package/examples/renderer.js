const api = window.desktopProvisioning;
const element = id => document.getElementById(id);
const show = value => { element("result").textContent = value; };
async function run(operation) { try { await operation(); } catch (error) { show(error.message || "Operation failed"); } }
if (!api?.available) show("Web Bluetooth unavailable. Check Electron/OS Bluetooth support.");
api?.onCandidates(devices => {
  element("candidates").replaceChildren();
  for (const device of devices) {
    const item = document.createElement("li"); const button = document.createElement("button");
    button.textContent = `${device.name} (${device.transportId.slice(-6)})`;
    button.onclick = () => run(() => api.select(device.transportId));
    item.append(button); element("candidates").append(item);
  }
});
element("scan").onclick = () => run(async () => {
  show("Scanning. Select your box below.");
  const [candidate] = await api.scan(element("legacy").checked);
  const info = await api.connect(candidate.transportId);
  element("info").textContent = JSON.stringify(info, null, 2); show("GATT connected; identity metadata read. Confirm fingerprint before binding.");
});
element("cancel").onclick = () => run(() => api.cancel());
element("disconnect").onclick = () => run(async () => { await api.disconnect(); element("info").textContent = "Disconnected"; show("Disconnected"); });
element("status").onclick = () => run(async () => { const status = await api.status(); show(`Device state: ${status.state}${status.reason ? ` (${status.reason})` : ""}`); });
element("networks").onclick = () => run(async () => { const networks = await api.networks(); element("networks-result").textContent = networks.map(item => `${item.ssid} (${item.signal})`).join("\n"); });
element("wifi").onsubmit = event => { event.preventDefault(); void run(async () => {
  if (!element("legacy").checked || !window.confirm("Send Wi-Fi credentials using legacy plaintext GATT to the selected box? Use only in your controlled test environment.")) return;
  const credentials = {ssid: element("ssid").value, password: element("password").value, security: element("security").value};
  element("password").value = "";
  try { const status = await api.provision(credentials); show(`Device state: ${status.state}${status.reason ? ` (${status.reason})` : ""}`); }
  finally { credentials.password = ""; }
}); };
