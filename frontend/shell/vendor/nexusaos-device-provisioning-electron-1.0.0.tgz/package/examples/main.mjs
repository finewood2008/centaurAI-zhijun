import {app, BrowserWindow, dialog} from "electron";
import {fileURLToPath} from "node:url";
import {installElectronBluetoothPicker} from "../dist/main.js";

// Some Linux Chromium/BlueZ combinations require this switch. It does not replace OS permissions.
if (process.platform === "linux") app.commandLine.appendSwitch("enable-experimental-web-platform-features");
const smokeTimer = process.env.DESKTOP_PROVISIONING_SMOKE === "1" ? setTimeout(() => { console.error("Desktop provisioning smoke timed out"); app.exit(1); }, 20_000) : undefined;
app.whenReady().then(async () => {
const documentUrl = new URL("./index.html", import.meta.url).href;
const window = new BrowserWindow({width: 760, height: 780, webPreferences: {
  preload: fileURLToPath(new URL("./preload.mjs", import.meta.url)),
  contextIsolation: true, nodeIntegration: false, sandbox: false,
  partition: "nexusaos-provisioning-demo",
}});
const pageErrors = [];
window.webContents.on("preload-error", (_event, _path, error) => pageErrors.push(error.message));
window.webContents.on("did-fail-load", (_event, code) => pageErrors.push(`load:${code}`));
const picker = installElectronBluetoothPicker({webContents: window.webContents, documentUrl});
window.webContents.setWindowOpenHandler(() => ({action: "deny"}));
window.webContents.on("will-navigate", (event, url) => { if (url !== documentUrl) event.preventDefault(); });
window.webContents.session.setPermissionCheckHandler((contents, permission, _origin, details) =>
  contents === window.webContents && permission === "bluetooth" && details.isMainFrame === true && window.webContents.getURL() === documentUrl);
window.webContents.session.setBluetoothPairingHandler(async (details, callback) => {
  // Never silently confirm a PIN. Unsupported PIN entry remains a clear OS/platform limitation.
  if (!["confirm", "confirmPin"].includes(details.pairingKind)) { callback({confirmed: false}); return; }
  const {response} = await dialog.showMessageBox(window, {type: "question", buttons: ["Cancel", "Pair"], defaultId: 0, cancelId: 0,
    message: details.pairingKind === "confirmPin" ? `Does the box show pairing PIN ${details.pin}?` : "Pair with the selected AI box?"});
  callback({confirmed: response === 1});
});
window.on("closed", () => { picker.dispose(); app.quit(); });
await window.loadURL(documentUrl);
if (process.env.DESKTOP_PROVISIONING_SMOKE === "1") {
  try {
    const result = await window.webContents.executeJavaScript(`({bridgeAvailable: typeof window.desktopProvisioning?.scan === 'function', bluetoothAvailable: window.desktopProvisioning?.available === true, nodeExposed: typeof window.require !== 'undefined' || typeof window.process !== 'undefined'})`);
    if (!result.bridgeAvailable || !result.bluetoothAvailable || result.nodeExposed || pageErrors.length) throw new Error("Desktop provisioning shell smoke failed");
    console.log(JSON.stringify({test: "electron-provisioning-shell", ...result, errors: pageErrors, bluetoothScanPerformed: false}));
    clearTimeout(smokeTimer);
    app.exit(0);
  } catch (error) { console.error(error.message); app.exit(1); }
}
}).catch(error => { console.error(error.message); app.exit(1); });
