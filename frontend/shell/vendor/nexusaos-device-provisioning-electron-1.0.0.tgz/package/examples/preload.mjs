import {contextBridge, ipcRenderer} from "electron";
import {createElectronGattProvisioningAdapter, createProvisioningSession} from "../dist/index.js";
import {BLUETOOTH_PICKER_CHANNELS} from "../dist/main.js";

let adapter;
let session;
let scanPending = false;
const callbacks = new Set();
ipcRenderer.on(BLUETOOTH_PICKER_CHANNELS.candidates, (_event, devices) => {
  for (const callback of callbacks) callback(devices);
});
const cancelSelection = () => ipcRenderer.invoke(BLUETOOTH_PICKER_CHANNELS.cancel);
contextBridge.exposeInMainWorld("desktopProvisioning", Object.freeze({
  available: Boolean(navigator.bluetooth?.requestDevice),
  async scan(allowLegacyPlaintextProvisioning = false) {
    if (scanPending) throw new Error("PROVISIONING_SCAN_IN_PROGRESS");
    // Keeping creation/request synchronous preserves the click's user activation.
    const previous = adapter;
    adapter = createElectronGattProvisioningAdapter({bluetooth: navigator.bluetooth, cancelSelection,
      allowLegacyPlaintextProvisioning: allowLegacyPlaintextProvisioning === true});
    session = createProvisioningSession(adapter, {scanTimeoutMs: 30_000});
    void previous?.dispose();
    scanPending = true;
    try { return await session.scan(); } finally { scanPending = false; }
  },
  select: id => ipcRenderer.invoke(BLUETOOTH_PICKER_CHANNELS.select, id),
  cancel: () => adapter?.stopScan(),
  onCandidates(callback) { callbacks.add(callback); return () => callbacks.delete(callback); },
  async connect(id) { if (!session) throw new Error("PROVISIONING_NOT_STARTED"); return session.connect(id); },
  async status() { if (!session) throw new Error("PROVISIONING_NOT_STARTED"); return session.refreshStatus(); },
  async networks() { if (!session) throw new Error("PROVISIONING_NOT_STARTED"); return session.scanWifiNetworks(); },
  async provision(credentials) {
    if (!session) throw new Error("PROVISIONING_NOT_STARTED");
    await session.startSession();
    await session.provisionWifi(credentials);
    return session.refreshStatus();
  },
  async disconnect() { await session?.disconnect(); await adapter?.dispose(); },
}));
