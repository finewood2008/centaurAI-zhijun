# Electron 桌面扫描与 GATT 配网

`@nexusaos/device-provisioning-electron` 提供真实 Electron Web Bluetooth 适配器，可直接交给 `@nexusaos/device-provisioning-uni` 的配网/所有权绑定编排。这里的 `uni` 包实际是平台无关编排，不需要 uni-app 运行时。

已实现：用户手势扫描并选择盒子、GATT 服务/特征发现、设备身份元数据读取、Wi-Fi 扫描、配网会话、状态通知和查询、命令分片串行发送、取消扫描、断连和订阅清理。蓝牙 transportId 是当前桌面的临时标识，不能替代盒子 device_id。读取 device-info 不等于已通过密码学身份认证；绑定必须继续使用配对 challenge/proof 流程。

## 凭据安全与固件依赖

当前盒子 `scripts/centauros-provisioning-ble-gatt` 接收普通 JSON 并直接读取 `payload.ssid/password`，没有 AEAD 解密。`schema_version: 2` 与 SHA-256 checksum **不代表加密**。

适配器默认拒绝 Wi-Fi 凭据写入，返回 `PROVISIONING_ENCRYPTION_UNAVAILABLE`。若提供 `secureCommands`，由宿主建立并验证与固件兼容的加密会话，再编码命令；编码失败直接失败，绝不自动降级。此接口本身不表示现有固件支持 AEAD。生产安全配网仍依赖盒子固件支持经过认证的加密协议。

仅在明确选择的开发/受控环境中可设置 `allowLegacyPlaintextProvisioning: true`，使用现有盒子 GATT 配网协议。这个开关不是加密，也不是默认行为；demo 需要用户先勾选提示，并再次确认提交。认证安全协议不可协商时不能自动打开这个开关。SDK 和 demo 不输出密码、命令 body、配对 token 日志；demo 提交后清空密码输入框。

## 宿主接入

Electron 37.x 是当前接入范围，实际编译/桌面 smoke 使用 37.10.3。宿主需要安装 Electron，包将其声明为 optional peer，避免纯 renderer 适配器使用者被动下载 Electron 二进制。公开类型使用 WebContents 的最小结构接口，`./main` 不引入 Electron 的全局类型声明，因此 SDK 消费者无需加载 Electron/Node 环境类型即可检查接口。

主进程给配网页面创建独立窗口和 session，加载本地可信页面。禁用 Node 暴露，使用 `contextIsolation: true`；拒绝跳转到外部页面和新窗口。挂载 picker：

```ts
import { installElectronBluetoothPicker } from '@nexusaos/device-provisioning-electron/main';

const picker = installElectronBluetoothPicker({
  webContents: setupWindow.webContents,
  documentUrl: trustedSetupDocumentUrl, // 精确 URL，不接收 renderer 传入的 URL
  timeoutMs: 30_000,
});
// 销毁窗口时自动取消请求并注销处理器；也可显式 picker.dispose()。
```

picker 使用 `webContents.ipc` 注册限定当前窗口的通道，校验精确文档 URL、sender 与顶层 frame。它只公布候选名称/临时 ID，用户选择时验证 ID 在本次扫描结果中，不自动连接第一台设备。preload 只暴露如下窄接口，不把 ipcRenderer 本身传给页面：

```ts
import { ipcRenderer, contextBridge } from 'electron';
import { BLUETOOTH_PICKER_CHANNELS as channels } from '@nexusaos/device-provisioning-electron/main';

contextBridge.exposeInMainWorld('setupPicker', {
  select: (id: string) => ipcRenderer.invoke(channels.select, id),
  cancel: () => ipcRenderer.invoke(channels.cancel),
  onCandidates: (listener: (devices: unknown[]) => void) => {
    const handler = (_event: unknown, devices: unknown[]) => listener(devices);
    ipcRenderer.on(channels.candidates, handler);
    return () => ipcRenderer.removeListener(channels.candidates, handler);
  },
});
```

在可信 renderer 的点击事件中，或在本包 demo 的受限 ESM preload 中创建适配器：

```ts
import { createElectronGattProvisioningAdapter, createProvisioningSession } from '@nexusaos/device-provisioning-electron';

const adapter = createElectronGattProvisioningAdapter({
  bluetooth: navigator.bluetooth,
  cancelSelection: () => window.setupPicker.cancel(),
});
const session = createProvisioningSession(adapter, { scanTimeoutMs: 30_000 });
scanButton.onclick = async () => {
  const [candidate] = await session.scan(); // 同步进入 requestDevice，保留点击的用户激活
  const box = await session.connect(candidate.transportId);
  // 展示 box，并验证指纹/配对证明。扫描返回的是用户选择的一个候选。
};
// 用户选择框列表来自 onCandidates；不是静默批量访问附近所有设备。
// await session.scanWifiNetworks() 由盒子扫描 Wi-Fi，不修改桌面本机 Wi-Fi。
// await session.startSession(); await session.provisionWifi(credentials);
// await session.disconnect(); await adapter.dispose();
```

GATT 写入按默认 20 字节串行分片，保持现有盒子“累积原始 JSON 字节再解析”的实际协议。不要对每片单独包装为 JSON。`chunkSize` 可显式设为 1–512；默认值避免假设桌面能读取 BLE MTU。多个状态订阅共用一条 GATT 通知，不会互相停止。状态查询发出 `status` 命令并按 request_id 等待对应通知，不读取上次缓存。

## 可运行桌面示例

在 SDK 根目录安装依赖并构建后：

```sh
npm run build
./node_modules/.bin/electron packages/device-provisioning-electron/examples/main.mjs
```

点击 **Scan nearby boxes**，在扫描结果中选择盒子；随后会读取 device-info。**Read status** 和 **Scan Wi-Fi from box** 是只读操作。扫描需要真实点击，Web Bluetooth 不支持后台静默 requestDevice。保持 legacy 复选框未勾选时不会发送 Wi-Fi 凭据。

```sh
DESKTOP_PROVISIONING_SMOKE=1 ./node_modules/.bin/electron packages/device-provisioning-electron/examples/main.mjs
node scripts/verify-electron-provisioning.mjs
```

smoke 检查真实 Electron 页面/preload 加载、Bluetooth API 是否存在、Node 是否未暴露，然后退出。它**不执行 BLE 扫描、不证明盒子连接成功**。协议单元验证使用故障注入测试，而不是实机验收。

## 平台范围与验收要求

| 平台 | 当前适配方式 | 需要实际验证的条件 |
| --- | --- | --- |
| macOS | Chromium Web Bluetooth / 系统蓝牙 | 打包应用包含 NSBluetoothAlwaysUsageDescription，用户授权，实际盒子广播与 GATT 通信 |
| Windows | Chromium Web Bluetooth | 可用 BLE 适配器/驱动；需要 PIN 时提供 pairing UI；实际盒子通信 |
| Linux | Chromium Web Bluetooth / BlueZ，实验支持 | demo 在 ready 前启用 enable-experimental-web-platform-features；BlueZ/系统权限；不能视为跨发行版生产支持 |

Electron 要求处理 `select-bluetooth-device`；Windows/Linux 额外配对校验可用 `setBluetoothPairingHandler`。demo 支持确认/确认 PIN，需手工输入 PIN 的设备返回拒绝，生产宿主应补 PIN 输入 UI。macOS 配对由系统处理。[Electron 设备访问](https://www.electronjs.org/docs/latest/tutorial/devices)、[Electron Session](https://www.electronjs.org/docs/latest/api/session)。

Chromium 的 Linux Web Bluetooth 仍列为部分实现，需要实验开关；不能把“API 存在”当硬件支持。[Web Bluetooth 实现状态](https://github.com/WebBluetoothCG/web-bluetooth/blob/main/implementation-status.md)、[Chrome Bluetooth 文档](https://developer.chrome.com/docs/capabilities/bluetooth)。macOS 应用的蓝牙用途描述见 [Apple NSBluetoothAlwaysUsageDescription](https://developer.apple.com/documentation/bundleresources/information-property-list/nsbluetoothalwaysusagedescription)。

每个平台真机验收须记录：OS/Electron/蓝牙适配器版本、目标盒子身份、独立扫描收到广播、用户选择、真实 GATT device-info/status、Wi-Fi 扫描、显式授权的配网进度、断开/重连。只有完成这些步骤才能标“实机通过”。Windows/Linux 实机仍需相应机器。

当前包没有 Classic SPP 原生扫描，也不自动切换电脑系统 Wi-Fi。SoftAP 应由用户连接临时热点后再执行独立适配；现有 SoftAP 是普通 HTTP，同样不能宣称 AEAD。App 账号认证、桌面 P2P sidecar、业务页面不经过 BLE 传输。
